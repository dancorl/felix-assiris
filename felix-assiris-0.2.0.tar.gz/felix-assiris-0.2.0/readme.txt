FELIX an approximate emulator for Felix-C-256 assembly (ASSIRIS) jobs
Copyright (c) 2023 Alexandru Dan Corlan, MD, PhD

This is release V0.2.0, December 1, 2023
It is part of the RASSIRIS project, to simulate Felix/Assiris-like computers
http://dan.corlan.net/software/emulators/felix-assiris/

Detailed documentation is at:
http://dan.corlan.net/software/emulators/felix-assiris/rassiris.pdf
and is also supplied in the distribution.

This code is released under the GNU General Public Licence version 2

INSTALLATION. 
On LINUX. Install gnat, the GNU Ada Translator. On debian: apt install gnat

Untar the distribution: tar xvzf felix-assiris-v0.2.0

Change to the directory: cd felix-assiris-v0.2.0

Say: make

The resulting binary, felix, can be run locally or copied to /usr/local/bin
for general availability on your system.

RUNNING.

The simulator is a linux executable, felix, that takes a jobfile on
stdin and prints on stdout. Try: ./felix <hello_world.assiris
for an example.

